# casting_defect_Annotation > 1st row images
https://universe.roboflow.com/marufmullah-yioyc/casting_defect_annotation

Provided by a Roboflow user
License: CC BY 4.0

